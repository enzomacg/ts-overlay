Place your icon .png files here: speaking.png, muted.png, deaf.png, whisp.png
